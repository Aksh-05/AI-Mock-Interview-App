import LandingPageRender from './LadingPageRender';


export default function LandingPage() {
  return( 
  
    <LandingPageRender />
  
  );
}
